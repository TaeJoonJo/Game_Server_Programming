#include "Protocols.h"
#include "Common.h"
#include "Client.h"
#include "NPC.h"
#include "Timer.h"
#include "DB.h"

HANDLE g_Iocp;
array<CChessClient*, MAX_USER> ChessClients;
array<CNPC*, NUM_NPC> aNPC;
unordered_map<INT, CChessClient*>mapChessClients;
mutex g_Mutex;

CTimer g_Timer;
CDB g_DB;

INT AcceptThread();
VOID WorkerThread();
VOID TimerThread();

CChessClient* InsertClient(SOCKET& socket);
const bool DeleteClient(CChessClient* pclient);
const bool DisconnectClient(CChessClient* pclient);

VOID UpdateViewList(INT id);
VOID UpdateNPCViewList(CNPC* pnpc);

VOID Broadcast(VOID *ppacket);
VOID SendPacket(INT id, VOID *ppacket);

VOID SendNPCChatTo(CNPC* pnpc, INT toId, TCHAR* msg);

static int API_get_player_x(lua_State* L)
{
	int player_id = (int)lua_tonumber(L, -1);
	lua_pop(L, 2);		// ���� �Ѱ��� �Լ� �Ѱ�
	int x = (int)mapChessClients[player_id]->GetX();
	lua_pushnumber(L, x);

	return 1;		// push ���� ����
}

static int API_get_player_y(lua_State * L)
{
	int player_id = (int)lua_tonumber(L, -1);
	lua_pop(L, 2);		// ���� �Ѱ��� �Լ� �Ѱ�
	int y = (int)mapChessClients[player_id]->GetY();
	lua_pushnumber(L, y);

	return 1;		// push ���� ����
}

static int API_get_npc_x(lua_State* L)
{
	int npc_id = (int)lua_tonumber(L, -1);
	lua_pop(L, 2);		// ���� �Ѱ��� �Լ� �Ѱ�
	int x = (int)aNPC[npc_id]->GetX();
	lua_pushnumber(L, x);

	return 1;		// push ���� ����
}

static int API_get_npc_y(lua_State * L)
{
	int npc_id = (int)lua_tonumber(L, -1);
	lua_pop(L, 2);		// ���� �Ѱ��� �Լ� �Ѱ�
	int y = (int)aNPC[npc_id]->GetY();
	lua_pushnumber(L, y);

	return 1;		// push ���� ����
}

static int API_SendNPCMessage(lua_State * L)
{
	int client_id = (int)lua_tonumber(L, -3);
	int npc_id = (int)lua_tonumber(L, -2);
	char* msg = (char*)lua_tostring(L, -1);			// ��ƿ����� �����ڵ带 �������� ����. -> ����ȸ�翡���� lua_towstring�� ���� ��
	wchar_t wmsg[MAX_STR_LEN];							// �츮�� �������� ������ ����. �׳� ��ȯ�ؼ� ��

	lua_pop(L, 4);		// ���� �Ѱ��� �Լ� �Ѱ�			

	size_t wlen, len;
	len = strnlen_s(msg, MAX_STR_LEN);

	mbstowcs_s(&wlen, wmsg, len, msg, _TRUNCATE);

	SendNPCChatTo(aNPC[npc_id], client_id, wmsg);

	return 0;		// push ���� ����
}

static int API_NPCDetectPlayer(lua_State* L)
{
	int client_id = (int)lua_tonumber(L, -2);
	int npc_id = (int)lua_tonumber(L, -1);

	lua_pop(L, 3);		// ���� �Ѱ��� �Լ� �Ѱ�
	CChessClient* pclinet = mapChessClients[client_id];

	aNPC[npc_id]->DetectPlayer(pclinet);
	g_Timer.AddTimer(GetTickCount64() + 1000, e_EventType::Timer_NPC_Run, pclinet, npc_id);

	return 0;		// push ���� ����
}

static int API_AddTimerNPCRun(lua_State* L)
{
	int time = (int)lua_tonumber(L, -3);
	int player_id = (int)lua_tonumber(L, -2);
	int npc_id = (int)lua_tonumber(L, -1);
	lua_pop(L, 4);

	CChessClient* pclinet = mapChessClients[player_id];

	g_Timer.AddTimer(GetTickCount64() + time, e_EventType::Timer_NPC_Run, pclinet, npc_id);

	return 0;		// push ���� ����
}

static int API_NPCRunFinish(lua_State* L)
{
	int npc_id = (int)lua_tonumber(L, -1);
	lua_pop(L, 2);

	aNPC[npc_id]->m_eMoveType = e_NPCMoveType::e_RandomMove;

	return 0;		// push ���� ����
}

VOID SendLoginOk(INT id)
{
	sc_packet_login_ok packet;
	packet.size = sizeof(sc_packet_login_ok);
	packet.type = e_sc_PacketType::Login_Ok;
	packet.id = id;

	SendPacket(id, &packet);
}

VOID SendLoginFail(INT id)
{
	sc_packet_login_fail packet;
	packet.size = sizeof(sc_packet_login_fail);
	packet.type = e_sc_PacketType::Login_Fail;

	SendPacket(id, &packet);
}

VOID SendSignupOk(INT id)
{
	sc_packet_signup_ok packet;
	packet.size = sizeof(sc_packet_signup_ok);
	packet.type = e_sc_PacketType::Signup_Ok;

	SendPacket(id, &packet);
}	

VOID SendSignupFail(INT id)
{
	sc_packet_signup_fail packet;
	packet.size = sizeof(sc_packet_signup_fail);
	packet.type = e_sc_PacketType::Signup_Fail;

	SendPacket(id, &packet);
}

VOID RecvLogin(INT id)
{
	g_Mutex.lock();
	auto clients = mapChessClients;
	CChessClient* pclient = clients[id];
	g_Mutex.unlock();

	sc_packet_put_player packet;
	packet.id = id;
	packet.size = sizeof(sc_packet_put_player);
	packet.type = e_sc_PacketType::PutPlayer;
	packet.x = pclient->GetX();
	packet.y = pclient->GetY();

	Broadcast(&packet);
	
	for (auto& client : clients)
	{
		pclient = client.second;
		if (pclient->GetID() == id) continue;

		sc_packet_put_player packet2;
		packet2.id = pclient->GetID();
		packet2.size = sizeof(sc_packet_put_player);
		packet2.x = pclient->GetX();
		packet2.y = pclient->GetY();
		packet2.type = sc_PACKETTYPE::PutPlayer;

		SendPacket(id, &packet2);
	}
}

VOID SendLogout(INT id, bool isBroad = false)
{
	sc_packet_logout packet;
	packet.id = id;
	packet.size = sizeof(sc_packet_logout);
	packet.type = sc_PACKETTYPE::Logout;

	if (isBroad == true)
		Broadcast(&packet);
	else
		SendPacket(id, &packet);
}

VOID SendMovePlayer(INT id, bool isBroad = false)
{
	g_Mutex.lock();
	CChessClient* pclient = mapChessClients[id];
	g_Mutex.unlock();

	sc_packet_move_player packet;
	packet.id = id;
	packet.size = sizeof(sc_packet_move_player);
	packet.x = pclient->GetX();
	packet.y = pclient->GetY();
	packet.type = sc_PACKETTYPE::MovePlayer;

	if (isBroad == true)
		Broadcast(&packet);
	else
		SendPacket(id, &packet);
}
VOID SendMovePlayerTo(INT myId, INT toId)
{
	g_Mutex.lock();
	CChessClient* pclient = mapChessClients[myId];
	g_Mutex.unlock();

	sc_packet_move_player packet;
	packet.id = myId;
	packet.size = sizeof(sc_packet_move_player);
	packet.x = pclient->GetX();
	packet.y = pclient->GetY();
	packet.type = sc_PACKETTYPE::MovePlayer;

	SendPacket(toId, &packet);
}

// �������� ���
VOID SendPutPlayer(INT id, bool isBroad = false)
{
	g_Mutex.lock();
	CChessClient* pclient = mapChessClients[id];
	g_Mutex.unlock();

	sc_packet_put_player packet;
	packet.id = id;
	packet.size = sizeof(sc_packet_put_player);
	packet.x = pclient->GetX();
	packet.y = pclient->GetY();
	packet.type = sc_PACKETTYPE::PutPlayer;

	if (isBroad == true)
		Broadcast(&packet);
	else
		SendPacket(id, &packet);
}
VOID SendPutPlayerTo(INT myId, INT toId)
{
	g_Mutex.lock();
	CChessClient* pclient = mapChessClients[myId];
	g_Mutex.unlock();

	sc_packet_put_player packet;
	packet.id = myId;
	packet.size = sizeof(sc_packet_put_player);
	packet.x = pclient->GetX();
	packet.y = pclient->GetY();
	packet.type = sc_PACKETTYPE::PutPlayer;

	SendPacket(toId, &packet);
}

VOID SendRemovePlayer(INT id, bool isBroad = false)
{
	sc_packet_remove_player packet;
	packet.id = id;
	packet.size = sizeof(sc_packet_remove_player);
	packet.type = sc_PACKETTYPE::RemovePlayer;

	if (isBroad == true)
		Broadcast(&packet);
	else
		SendPacket(id, &packet);
}
VOID SendRemovePlayerTo(INT myId, INT toId)
{
	sc_packet_remove_player packet;
	packet.id = myId;
	packet.size = sizeof(sc_packet_remove_player);
	packet.type = sc_PACKETTYPE::RemovePlayer;

	SendPacket(toId, &packet);
}

VOID SendMoveNPCTo(CNPC* pnpc, INT toId)
{
	sc_packet_move_npc packet;
	packet.id = pnpc->GetID();
	packet.size = sizeof(sc_packet_move_npc);
	packet.x = pnpc->GetX();
	packet.y = pnpc->GetY();
	packet.type = sc_PACKETTYPE::MoveNPC;

	SendPacket(toId, &packet);
}

VOID SendPutNPCTo(CNPC* pnpc, INT toId)
{
	sc_packet_put_npc packet;
	packet.id = pnpc->GetID();
	packet.size = sizeof(sc_packet_put_npc);
	packet.x = pnpc->GetX();
	packet.y = pnpc->GetY();
	packet.type = sc_PACKETTYPE::PutNPC;

	SendPacket(toId, &packet);
}

VOID SendRemoveNPCTo(CNPC* pnpc, INT toId)
{
	sc_packet_remove_npc packet;
	packet.id = pnpc->GetID();
	packet.size = sizeof(sc_packet_remove_npc);
	packet.type = sc_PACKETTYPE::RemoveNPC;

	SendPacket(toId, &packet);
}

VOID SendNPCChatTo(CNPC* pnpc, INT toId, TCHAR* msg)
{
	sc_packet_npc_chat packet;
	packet.id = pnpc->GetID();
	packet.size = sizeof(sc_packet_npc_chat);
	packet.type = sc_PACKETTYPE::NPCChat;
	wcscpy_s(packet.msg, msg);

	SendPacket(toId, &packet);
}

// ��� �÷��̾�� �Ѹ�
VOID Broadcast(VOID *ppacket)
{
	CChessClient* pclient = nullptr;
	g_Mutex.lock();
	auto clients = mapChessClients;
	g_Mutex.unlock();
	for(auto &client : clients) {
		pclient = client.second;
		if (pclient == nullptr) continue;

		SendPacket(pclient->m_ClientInfo->GetId(), ppacket);
	}
}

VOID SendPacket(INT id, VOID *ppacket)
{
	g_Mutex.lock();
	CChessClient* pclient = mapChessClients[id];
	g_Mutex.unlock();
	if (pclient == nullptr) return;

	SOCKETINFO* psocketInfo = new SOCKETINFO;
	char *p = reinterpret_cast<char *>(ppacket);
	memcpy(psocketInfo->buf, ppacket, p[0]);
	psocketInfo->wsaBuf.buf = psocketInfo->buf;
	psocketInfo->wsaBuf.len = p[0];
	psocketInfo->eventType = e_EventType::Event_Send;
	psocketInfo->targetid = id;
	ZeroMemory(&psocketInfo->overlapped, sizeof(WSAOVERLAPPED));

	//g_Mutex.lock();
	if (WSASend(pclient->GetSocket(), &psocketInfo->wsaBuf, 1, NULL, 0, &psocketInfo->overlapped, 0) == SOCKET_ERROR)
	{
		if (WSAGetLastError() != WSA_IO_PENDING)
		{
			//cout << "Error - Fail WSASend(error_code : " << WSAGetLastError() << ") in SendPacket(), ID : " << id << "\n";
		}
	}
	//g_Mutex.unlock();
}

void InitalizeObjects() 
{
	cout << "Initalize Objects Start!\n";

	for (int i = 0; i < MAX_USER; ++i)
		ChessClients[i] = new CChessClient;

	for (DWORD i = 0; i < NUM_NPC; ++i) {
		aNPC[i] = new CNPC;
		aNPC[i]->Initalize(i);
		lua_State* L = aNPC[i]->m_L;
		lua_getglobal(L, "set_uid");
		lua_pushnumber(L, aNPC[i]->GetID());
		lua_pcall(L, 1, 0, 0);
		lua_register(L, "API_get_player_x", API_get_player_x);
		lua_register(L, "API_get_player_y", API_get_player_y);
		lua_register(L, "API_get_npc_x", API_get_npc_x);
		lua_register(L, "API_get_npc_y", API_get_npc_y);
		lua_register(L, "API_SendNPCMessage", API_SendNPCMessage);
		lua_register(L, "API_NPCDetectPlayer", API_NPCDetectPlayer);
		lua_register(L, "API_AddTimerNPCRun", API_AddTimerNPCRun);
		lua_register(L, "API_NPCRunFinish", API_NPCRunFinish);
	}

	cout << "Initalize Objects OK!\n";
}

int main()
{
	InitalizeObjects();

	vector<thread> vecworkerThreads;

	g_Iocp = CreateIoCompletionPort(INVALID_HANDLE_VALUE, 0, 0, 0);
	g_Timer.Initialize(g_Iocp);

	//g_DB.InitalizeDB();
	//
	//if (g_DB.ConnectDB((SQLWCHAR*)L"Game_Server_2013180038", (SQLWCHAR*)L"TJ", (SQLWCHAR*)L"102030") == false)
	//	while (1);

	cout << "Server Start!\n";

	for (int i = 0; i < 8; ++i)
		vecworkerThreads.emplace_back(thread{ WorkerThread });
	thread acceptThread{ AcceptThread };
	thread timerThread{ TimerThread };

	timerThread.join();

	acceptThread.join();

	for (auto& thread : vecworkerThreads)
		thread.join();
	
	g_DB.ClearDB();

	g_Mutex.lock();
	for (int i = 0; i < MAX_USER; ++i)
		delete ChessClients[i];
	mapChessClients.clear();
	g_Mutex.unlock();

	for (DWORD i = 0; i < NUM_NPC; ++i)
		delete aNPC[i];

	return 0;
}

INT AcceptThread()
{
	// Winsock Start - windock.dll �ε�
	WSADATA WSAData;
	if (WSAStartup(MAKEWORD(2, 2), &WSAData) != 0)
	{
		cout << "Error - Can not load 'winsock.dll' file\n";
		return 1;
	}

	// 1. ���ϻ���  
	SOCKET listenSocket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);	// WSA_FLAG_OVERLAPPED �÷��� �ݵ�� �־���� OVEERLAPPED I/O ����
	if (listenSocket == INVALID_SOCKET)
	{
		printf("Error - Invalid socket\n");
		return 1;
	}

	// �������� ��ü����
	SOCKADDR_IN serverAddr;
	memset(&serverAddr, 0, sizeof(SOCKADDR_IN));
	serverAddr.sin_family = PF_INET;
	serverAddr.sin_port = htons(SERVER_PORT);
	serverAddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);

	// 2. ���ϼ���
	if (bind(listenSocket, (struct sockaddr*) & serverAddr, sizeof(SOCKADDR_IN)) == SOCKET_ERROR)
	{
		printf("Error - Fail bind\n");
		// 6. ��������
		closesocket(listenSocket);
		// Winsock End
		WSACleanup();
		return 1;
	}

	// 3. ���Ŵ�⿭����
	if (listen(listenSocket, 5) == SOCKET_ERROR)
	{
		printf("Error - Fail listen\n");
		// 6. ��������
		closesocket(listenSocket);
		// Winsock End
		WSACleanup();
		return 1;
	}

	SOCKADDR_IN clientAddr;
	int addrLen = sizeof(SOCKADDR_IN);
	memset(&clientAddr, 0, addrLen);
	SOCKET clientSocket;
	DWORD flags;

	while (1)
	{
		clientSocket = accept(listenSocket, (struct sockaddr*) & clientAddr, &addrLen);
		if (clientSocket == INVALID_SOCKET)
		{
			printf("Error - Accept Failure\n");
			return 1;
		}
		//cout << "Ŭ���̾�Ʈ ���� : IP �ּ� = " << inet_ntoa(clientAddr.sin_addr) << ", ��Ʈ ��ȣ = " << ntohs(clientAddr.sin_port) << "\n";

		// ���Ʈ�ϰ� �ش� Ŭ���̾�Ʈ�� ���� Ŭ���̾�Ʈ Ŭ���� ������ ���̵� �������ְ� ���Ϳ� �־��ش�. Ŭ���̾�Ʈ�� ���̵� �Ѱ��ִ°Ŵ� ù��° ���嶧 Login enum�� �̿��� ���ش�.
		
		bool optval = true;
		setsockopt(clientSocket, IPPROTO_TCP, TCP_NODELAY, (char*)& optval, sizeof(optval));
		
		CChessClient *pclient = InsertClient(clientSocket);

		CreateIoCompletionPort(reinterpret_cast<HANDLE>(clientSocket), g_Iocp, reinterpret_cast<ULONG_PTR>(pclient), 0);
		flags = 0;
		INT id = pclient->GetID();
		//cout << "ID : " << id << " �� ����!\n";

		SendLoginOk(id);
		//RecvLogin(id);
		SendPutPlayer(id, false);
		UpdateViewList(id);

		if (WSARecv(clientSocket, &(pclient->m_ClientInfo->m_SocketInfo.wsaBuf), 1, NULL, &flags, &(pclient->m_ClientInfo->m_SocketInfo.overlapped), 0))	// NULL �� ���� ������ ��������� ���� �� ���� �ִ�.
		{
			if (WSAGetLastError() == WSA_IO_PENDING)		// ������ �ʰ� ���� �־�ߵȴ�. - ���� ����.
			{
				//cout << "WSA_IO_PENDING in WSARecv\n";
			}
			else
			{
				cout << "Error - IO pending Failure " << WSAGetLastError() << "\n";
				//cout << "ID : " << id << "Logout!\n";
				//SendLogout(id, TRUE);
				//vClients[id]->Logout();
			}
		}
		else
		{
			//cout << "Non Overlapped Recv return.\n";
			//cout << "ID : " << id << "Logout!\n";
			//SendLogout(id, TRUE);
			//vClients[id]->Logout();
		}
	}

	// 6-2. ���� ��������
	closesocket(listenSocket);

	// Winsock End
	WSACleanup();
}

VOID WorkerThread()
{
	DWORD				ioByte = 0;
	DWORD				retval = 0;
	CChessClient		*pclient = nullptr;
	SOCKETINFO			*poverlapped = nullptr;

	while (1)
	{
		ioByte = 0;
		retval = 0;
		pclient = nullptr;
		poverlapped = nullptr;

		if (false == GetQueuedCompletionStatus(g_Iocp, &ioByte,
			reinterpret_cast<PULONG_PTR>(&pclient),
			reinterpret_cast<LPOVERLAPPED*>(&poverlapped), INFINITE))
			retval = WSAGetLastError();

		if (retval == 0)
		{
			e_EventType etype = poverlapped->eventType;

			if (etype == e_EventType::Timer_NPC_Move)
			{
				//for (DWORD i = 0; i < NUM_NPC; ++i) {
				//	aNPC[i]->Move();
				//	UpdateNPCViewList(aNPC[i]);
				//}
				DWORD npcid = poverlapped->targetid;
				CNPC* pnpc = aNPC[npcid];
				pnpc->Move();
				UpdateNPCViewList(pnpc);

				delete poverlapped;
				
			}
			else if (etype == e_EventType::Timer_NPC_Run)
			{
				DWORD npcid = poverlapped->targetid;
				//aNPC[npcid]->m_eMoveType = e_NPCMoveType::e_RandomMove;

				lua_State* L = aNPC[npcid]->m_L;

				// lua ����ӽ��� ��Ƽ������ �����ȵ� lock �ʿ�
				aNPC[npcid]->m_lMutex.lock();
				lua_getglobal(L, "event_npc_run");
				lua_pushnumber(L, pclient->GetID());
				lua_pcall(L, 1, 0, 0);
				aNPC[npcid]->m_lMutex.unlock();

				delete poverlapped;
			}

			if (pclient == nullptr)
				continue;

			if (ioByte == 0) {
				cout << "WorkerThread LogOut ID : " << static_cast<int>(pclient->GetID()) << "\n";
				DisconnectClient(pclient);
				continue;
			}

			switch (etype)
			{
			case e_EventType::Event_Recv:
			{
				//cout << "���� ����Ʈ : " <<ioByte << "\n";
				char* buf = pclient->m_ClientInfo->m_SocketInfo.buf;
				int packetSize = 0;
				if (pclient->m_ClientInfo->m_PreSize != 0)
					packetSize = pclient->m_ClientInfo->m_RecvBuf[0];
				while (ioByte > 0)
				{
					if (packetSize == 0)		// ������ ����
						packetSize = buf[0];
					int required = packetSize - pclient->m_ClientInfo->m_PreSize;	// ��Ŷ�� �ϼ��ϴµ� �ʿ��� ����Ʈ ��
					if (ioByte < required)	// ���ú� ���� �����Ͱ� �ʿ��� �����ͺ��� ������ ��Ŷ�� �ϼ� ��ų�� ����.
					{
						memcpy(pclient->m_ClientInfo->m_RecvBuf + pclient->m_ClientInfo->m_PreSize, buf, ioByte);
						pclient->m_ClientInfo->m_PreSize += ioByte;
						break;
					}
					else // �����͸� �ϼ��� �� �ִٸ�,,
					{
						memcpy(pclient->m_ClientInfo->m_RecvBuf + pclient->m_ClientInfo->m_PreSize, buf, required);	// ��Ŷ�� �ϼ���Ű�µ� �ʿ��Ѹ�ŭ�� �����Ѵ�.

						cs_packet_base* buf = reinterpret_cast<cs_packet_base*>(pclient->m_ClientInfo->m_RecvBuf);

						BYTE type = buf->type;
						e_sc_PacketType escType;

						switch (type)
						{
						case e_cs_PacketType::Login:
						{
							cs_packet_login* pbuf = reinterpret_cast<cs_packet_login*>(pclient->m_ClientInfo->m_RecvBuf);

							TCHAR* pname = pbuf->name;
							wcout << L"Try to Login To Name : " << pname << "\n";

							if (g_DB.LoginToDB(pname, pclient) == true) {
								memcpy(pclient->m_Name, pname, wcslen(pname) * 2 + 2);
								escType = e_sc_PacketType::Login_Ok;
							}
							else
								escType = e_sc_PacketType::Login_Fail;
						} break;
						case e_cs_PacketType::Signup:
						{
							cs_packet_signup* pbuf = reinterpret_cast<cs_packet_signup*>(pclient->m_ClientInfo->m_RecvBuf);

							TCHAR* pname = pbuf->name;
							wcout << L"Try to Signup To Name : " << pname << "\n";

							if (g_DB.SignupToDB(pname) == true) 
								escType = e_sc_PacketType::Signup_Ok;
							else
								escType = e_sc_PacketType::Signup_Fail;
						} break;
						case e_cs_PacketType::Up:
						{
							if (pclient->m_Y > 0)					pclient->m_Y--;
							escType = e_sc_PacketType::MovePlayer;
						} break;
						case e_cs_PacketType::Down:
						{
							if (pclient->m_Y < WORLD_HEIGHT - 1)	pclient->m_Y++;
							escType = e_sc_PacketType::MovePlayer;
						} break;
						case e_cs_PacketType::Left:
						{
							if (pclient->m_X > 0)					pclient->m_X--;
							escType = e_sc_PacketType::MovePlayer;
						} break;
						case e_cs_PacketType::Right:
						{
							if (pclient->m_X < (WORLD_HEIGHT - 1))	pclient->m_X++;
							escType = e_sc_PacketType::MovePlayer;
						} break;
						case e_cs_PacketType::IDLE:
						{
							escType = e_sc_PacketType::MovePlayer;
						} break;
						case e_cs_PacketType::Teleport:
						{
							pclient->m_X = DEBUG_TELEPORT_X;
							pclient->m_Y = DEBUG_TELEPORT_Y;
							escType = e_sc_PacketType::MovePlayer;
						}
						}

						int id = pclient->GetID();
						// send �κ� �߰�����
						switch (escType)
						{
						case e_sc_PacketType::Login_Ok:
						{
							SendLoginOk(id);
							SendPutPlayer(id);
							UpdateViewList(id);
						} break;
						case e_sc_PacketType::Login_Fail:
						{
							SendLoginFail(id);
						} break;
						case e_sc_PacketType::Signup_Ok:
						{
							SendSignupOk(id);
						} break;
						case e_sc_PacketType::Signup_Fail:
						{
							SendSignupFail(id);
						} break;
						case e_sc_PacketType::Logout:
						{
							SendLogout(id, true);
						} break;
						case e_sc_PacketType::MovePlayer:
						{
							SendMovePlayer(id, false);
							UpdateViewList(id);
						} break;
						case e_sc_PacketType::PutPlayer:
						{
							SendPutPlayer(id, false);
							//UpdateViewList(id);
						} break;
						case e_sc_PacketType::RemovePlayer:
						{
							SendRemovePlayer(id, false);
							//UpdateViewList(id);
						} break;
						default: cout << "�� �� ���� ��Ŷ ����\n"; break;
						}
						pclient->m_ClientInfo->m_PreSize = 0;
						ioByte -= required;
						buf += required;
						packetSize = 0;
					}
				}
				DWORD flags = 0;
				if (WSARecv(pclient->m_ClientInfo->GetSocket(), &pclient->m_ClientInfo->m_SocketInfo.wsaBuf, 1, NULL, &flags, &pclient->m_ClientInfo->m_SocketInfo.overlapped, 0))
				{
					if (WSAGetLastError() != WSA_IO_PENDING)
					{
						printf("Error - IO pending Failure\n");
						DisconnectClient(pclient);

						return;
					}
				}
				else // ���� ��������
				{
					/*cout << "Non Overlapped Recv return.\n";
					SendLogout(id, TRUE);
					pClient->Logout();*/

					return;
				}
			} break;
			case e_EventType::Event_Send:
			{
				delete poverlapped;
			} break;
			case e_EventType::Event_Player_Move:
			{
				int npc_id = poverlapped->targetid;
				lua_State* L = aNPC[npc_id]->m_L;

				// lua ����ӽ��� ��Ƽ������ �����ȵ� lock �ʿ�
				aNPC[npc_id]->m_lMutex.lock();
				lua_getglobal(L, "event_player_move");
				lua_pushnumber(L, pclient->GetID());
				lua_pcall(L, 1, 0, 0);
				aNPC[npc_id]->m_lMutex.unlock();

				delete poverlapped;
			}
			default: continue;
			}
		}
		else
		{
			if (WAIT_TIMEOUT == retval)
			{

			}
			else if (ERROR_NETNAME_DELETED == retval)
			{
				cout << "WorkerThread ERROR CODE : ERROR_NETNAME_DELETED\n";
				cout << "ID : " << static_cast<int>(pclient->GetID()) << " LogOut!\n";
				DisconnectClient(pclient);
			}
			else
			{
				cout << "GetQueuedCompletionStatus unknown Error " << WSAGetLastError() << "\n";
				cout << "ID : " << static_cast<int>(pclient->GetID()) << " LogOut!\n";
				DisconnectClient(pclient);
			}

			continue;
		}
	}
}

VOID TimerThread()
{
	while (1)
	{
		Sleep(1);

		g_Timer.ProcessTimer();
	}
}

CChessClient *InsertClient(SOCKET &socket)
{
	CChessClient* pclient = nullptr;
	
	{
		for (int i = 0; i < MAX_USER; ++i)
		{
			if (ChessClients[i]->m_bIsRun == false)
			{
				pclient = ChessClients[i];
				pclient->m_ClientInfo->m_Id = i;
				break;
			}
		}
		if (pclient != nullptr)
		{
			if (pclient->Initial(socket) == false)
				pclient = nullptr;

			g_Mutex.lock();
			mapChessClients[pclient->GetID()] = pclient;
			g_Mutex.unlock();
		}
	}

	return pclient;
}

const bool DeleteClient(CChessClient *pclient)
{
	//g_Mutex.lock();
	{
		pclient->m_bIsRun = false;
		g_Mutex.lock();
		pclient->m_ClientInfo->ClearIoBuffer();
		g_Mutex.unlock();

		CChessClient* potherClient = nullptr;
		// �ٸ� Ŭ����� �丮��Ʈ���� ��������
		g_Mutex.lock();
		auto clients = mapChessClients;
		g_Mutex.unlock();

		for (auto& client : clients) {
			potherClient = client.second;
			if (potherClient == nullptr)
				continue;
			if (pclient == potherClient)
				continue;
			
			potherClient->m_vlMutex.lock();
			if(potherClient->m_ViewList.count(pclient) > 0)
				potherClient->m_ViewList.erase(pclient);	
			potherClient->m_vlMutex.unlock();
		}
		
		for (DWORD i = 0; i < NUM_NPC; ++i) {
			aNPC[i]->m_vlMutex.lock();
			if (aNPC[i]->m_ViewList.count(pclient) > 0)
				aNPC[i]->m_ViewList.erase(pclient);
			aNPC[i]->m_vlMutex.unlock();
		}
		pclient->m_vlMutex.lock();
		{
			pclient->m_ViewList.clear();
		}
		pclient->m_vlMutex.unlock();
		pclient->m_npcvlMutex.lock();
		{
			pclient->m_NPCViewList.clear();
		}
		pclient->m_npcvlMutex.unlock();

		g_Mutex.lock();
		mapChessClients.erase(pclient->GetID());
		g_Mutex.unlock();
	}
	//g_Mutex.unlock();

	return true;
}

const bool DisconnectClient(CChessClient* pclient)
{
	//g_DB.SaveClientInfoInDB(pclient);

	DeleteClient(pclient);

	SendRemovePlayer(pclient->GetID(), true);

	return true;
}

// �þߴ� 7 x 7
VOID UpdateViewList(INT id)
{
	CChessClient* pclient = mapChessClients[id];

	float mx = pclient->GetX();
	float my = pclient->GetY();

	CChessClient* potherClient = nullptr;
	float ox = 0;
	float oy = 0;

	g_Mutex.lock();
	auto clients = mapChessClients;
	g_Mutex.unlock();

	for (auto& client : clients)
	{
		potherClient = client.second;
		if (potherClient == nullptr) continue;
		if (pclient == potherClient)
			continue;

		ox = potherClient->GetX();
		oy = potherClient->GetY();

		// �þ߾ȿ� ������ nearlist�� �־��ش�.
		if ((abs(mx - ox) <= VIEW_RADIUS) && (abs(my - oy) <= VIEW_RADIUS))
			pclient->m_NearList.emplace(potherClient);
	}
		
	// �þ� ����Ʈ�� ������
	for (auto& n : pclient->m_NearList) {
		// �þ߸���Ʈ���� ã�´�.
		pclient->m_vlMutex.lock();
		auto mv = find(pclient->m_ViewList.begin(), pclient->m_ViewList.end(), n);
		// �þ߸���Ʈ�� �����ٸ�
		if (mv == pclient->m_ViewList.end()) {
			pclient->m_ViewList.emplace(n);
			pclient->m_vlMutex.unlock();
			SendPutPlayerTo(n->GetID(), pclient->GetID());
			// �ٸ� Ŭ���� �þ߸���Ʈ �˻�
			n->m_vlMutex.lock();
			auto ov = find(n->m_ViewList.begin(), n->m_ViewList.end(), pclient);
			if (ov == n->m_ViewList.end()) {
				//n->m_ViewList.emplace_back(pclient);
				n->m_ViewList.emplace(pclient);
				n->m_vlMutex.unlock();
				SendPutPlayerTo(pclient->GetID(), n->GetID());
			}
			else {
				n->m_vlMutex.unlock();
				SendMovePlayerTo(pclient->GetID(), n->GetID());
			}
		}
		else {
			pclient->m_vlMutex.unlock();
			n->m_vlMutex.lock();
			auto ov = find(n->m_ViewList.begin(), n->m_ViewList.end(), pclient);
			if (ov == n->m_ViewList.end()) {
				//n->m_ViewList.emplace_back(pclient);
				n->m_ViewList.emplace(pclient);
				n->m_vlMutex.unlock();
				SendPutPlayerTo(pclient->GetID(), n->GetID());
			}
			else {
				n->m_vlMutex.unlock();
				SendMovePlayerTo(pclient->GetID(), n->GetID());
			}
		}
	}
	pclient->m_vlMutex.lock();
	auto vl = pclient->m_ViewList;
	pclient->m_vlMutex.unlock();
	for (auto& v : vl) {
		auto mn = find(pclient->m_NearList.begin(), pclient->m_NearList.end(), v);
		if (mn == pclient->m_NearList.end()) {
			pclient->m_RemoveList.emplace(v);
			SendRemovePlayerTo(v->GetID(), pclient->GetID());
			v->m_vlMutex.lock();
			auto ov = find(v->m_ViewList.begin(), v->m_ViewList.end(), pclient);
			if (ov == v->m_ViewList.end()) {
				v->m_vlMutex.unlock();
			}
			else {
				v->m_ViewList.erase(ov);
				v->m_vlMutex.unlock();
				SendRemovePlayerTo(pclient->GetID(), v->GetID());
			}
		}
		else {

		}
	}
		
	for (auto& r : pclient->m_RemoveList) {
		pclient->m_vlMutex.lock();
		auto mv = find(pclient->m_ViewList.begin(), pclient->m_ViewList.end(), r);
		if (mv == pclient->m_ViewList.end()) {
			pclient->m_vlMutex.unlock();
		}
		else {
			pclient->m_ViewList.erase(mv);
			pclient->m_vlMutex.unlock();
		}
	}
	
	pclient->m_RemoveList.clear();
	pclient->m_NearList.clear();

	///////////////////////////////////	NPC ///////////////////////////////////
	pclient->m_npcvlMutex.lock();
	auto npcView = pclient->m_NPCViewList;
	pclient->m_npcvlMutex.unlock();
	unordered_set<CNPC*> npcNear;

	float nx = 0;
	float ny = 0;
	for (DWORD i = 0; i < NUM_NPC; ++i)
	{
		nx = aNPC[i]->GetX();
		ny = aNPC[i]->GetY();

		if ((abs(mx - nx) <= VIEW_RADIUS) && (abs(my - ny) <= VIEW_RADIUS))
			npcNear.emplace(aNPC[i]);
	}

	for (auto& npc : npcView)
	{
		if (npcNear.count(npc) == 0) continue;
		npc->m_vlMutex.lock();
		if (0 < npc->m_ViewList.count(pclient)) {
			npc->m_vlMutex.unlock();
			continue;
		}
		else {
			npc->m_ViewList.emplace(pclient);
			npc->m_vlMutex.unlock();
		}
	}
	for (auto& npc : npcNear)
	{
		if (0 < npcView.count(npc)) continue;
		pclient->m_npcvlMutex.lock();
		pclient->m_NPCViewList.insert(npc);
		pclient->m_npcvlMutex.unlock();
		SendPutNPCTo(npc, pclient->GetID());
		if (npc->WakeUp() == true)
			g_Timer.AddTimer(GetTickCount64() + 1000, e_EventType::Timer_NPC_Move, nullptr, npc->GetID());
		npc->m_vlMutex.lock();
		if (0 == npc->m_ViewList.count(pclient)) {
			npc->m_ViewList.insert(pclient);
		}
		npc->m_vlMutex.unlock();
	}
	for (auto& npc : npcView)
	{
		if (0 < npcNear.count(npc)) continue;
		pclient->m_npcvlMutex.lock();
		pclient->m_NPCViewList.erase(npc);
		pclient->m_npcvlMutex.unlock();
		SendRemoveNPCTo(npc, pclient->GetID());
		npc->m_vlMutex.lock();
		if (0 < npc->m_ViewList.count(pclient)) 
			npc->m_ViewList.erase(pclient);
		npc->m_vlMutex.unlock();
	}

	for (auto& npc : npcNear)
	{
		SOCKETINFO* ex_over = new SOCKETINFO;
		ex_over->eventType = e_EventType::Event_Player_Move;
		ex_over->targetid = npc->GetID();
		PostQueuedCompletionStatus(g_Iocp, 1, reinterpret_cast<ULONG_PTR>(pclient), &ex_over->overlapped);
	}
}

VOID UpdateNPCViewList(CNPC* pnpc)
{
	float nx = pnpc->GetX();
	float ny = pnpc->GetY();

	pnpc->m_vlMutex.lock();
	auto viewList = pnpc->m_ViewList;
	pnpc->m_vlMutex.unlock();
	unordered_set<CChessClient*> nearList;
	unordered_set<CChessClient*> moveList;

	CChessClient* pclient = nullptr;
	float cx = 0;
	float cy = 0;

	g_Mutex.lock();
	auto clients = mapChessClients;
	g_Mutex.unlock();

	for (auto& client : clients)
	{
		pclient = client.second;
		if (pclient == nullptr) continue;

		cx = pclient->GetX();
		cy = pclient->GetY();

		if ((abs(nx - cx) <= VIEW_RADIUS) && (abs(ny - cy) <= VIEW_RADIUS))
			nearList.emplace(pclient);

		if ((abs(nx - cx) <= NPC_MOVE_RADIUS) && (abs(ny - cy) <= NPC_MOVE_RADIUS))
			moveList.emplace(pclient);
	}

	//for (auto pl : nearList) {
	//	if (0 == pl->m_NPCViewList.count(pnpc)) {
	//		pl->m_NPCViewList.insert(pnpc);
	//		SendPutNPCTo(pnpc, pl->GetID());
	//		if (viewList.count(pl) == 0)
	//			pnpc->m_ViewList.emplace(pl);
	//	}
	//	else
	//		SendMoveNPCTo(pnpc, pl->GetID());
	//}
	//// ����� �÷��̾� ó��
	//for (auto pl : viewList) {
	//	if (0 == nearList.count(pl)) {
	//		pnpc->m_ViewList.erase(pl);
	//		if (0 < pl->m_NPCViewList.count(pnpc)) {
	//			pl->m_NPCViewList.erase(pnpc);
	//			SendRemoveNPCTo(pnpc, pl->GetID());
	//		}
	//	}
	//}

	for (auto& pl : viewList)
	{
		if (0 == nearList.count(pl)) continue;
		pl->m_npcvlMutex.lock();
		if (0 < pl->m_NPCViewList.count(pnpc)) {
			pl->m_npcvlMutex.unlock();
			SendMoveNPCTo(pnpc, pl->GetID());
		}
		else {
			pl->m_NPCViewList.insert(pnpc);
			pl->m_npcvlMutex.unlock();
			SendPutNPCTo(pnpc, pl->GetID());
		}
	}
	for (auto& pl : nearList)
	{
		if (0 < viewList.count(pl)) continue;
		pnpc->m_vlMutex.lock();
		pnpc->m_ViewList.insert(pl);
		pnpc->m_vlMutex.unlock();
		pl->m_npcvlMutex.lock();
		if (0 == pl->m_NPCViewList.count(pnpc)) {
			pl->m_NPCViewList.insert(pnpc);
			pl->m_npcvlMutex.unlock();
			SendPutNPCTo(pnpc, pl->GetID());
		}
		else {
			pl->m_npcvlMutex.unlock();
			SendMoveNPCTo(pnpc, pl->GetID());
		}
	}
	for (auto& pl : nearList)
	{
		if (0 < viewList.count(pl)) continue;
		pnpc->m_vlMutex.lock();
		pnpc->m_ViewList.erase(pl);
		pnpc->m_vlMutex.unlock();
		pl->m_npcvlMutex.lock();
		if (0 < pl->m_NPCViewList.count(pnpc)) {
			pl->m_NPCViewList.erase(pnpc);
			pl->m_npcvlMutex.unlock();
			SendRemoveNPCTo(pnpc, pl->GetID());
		}
		else
			pl->m_npcvlMutex.unlock();
	}

	if (moveList.empty() == false)
		g_Timer.AddTimer(GetTickCount64() + 1000, e_EventType::Timer_NPC_Move, nullptr, pnpc->GetID());
	else
		pnpc->m_bIsSleep = true;
}