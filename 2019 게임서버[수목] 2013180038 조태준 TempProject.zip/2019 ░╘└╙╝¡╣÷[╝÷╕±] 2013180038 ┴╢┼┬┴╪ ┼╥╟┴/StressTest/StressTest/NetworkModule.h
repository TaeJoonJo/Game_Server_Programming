#pragma once

void InitializeNetwork();
void GetPointCloud(int *size, float **points);
