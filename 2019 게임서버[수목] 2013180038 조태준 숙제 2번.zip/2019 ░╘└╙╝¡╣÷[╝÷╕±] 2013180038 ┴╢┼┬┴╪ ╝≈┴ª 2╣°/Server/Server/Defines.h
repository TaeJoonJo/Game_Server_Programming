#pragma once

#define DEFAULTSIZE 50.f
#define BOARDSIZE 400.f