#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <Windows.h>
#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include <stdlib.h>
#include <ctime>
#include <random>

#include <vector>
#include <iterator>

#include "Defines.h"

using namespace std;