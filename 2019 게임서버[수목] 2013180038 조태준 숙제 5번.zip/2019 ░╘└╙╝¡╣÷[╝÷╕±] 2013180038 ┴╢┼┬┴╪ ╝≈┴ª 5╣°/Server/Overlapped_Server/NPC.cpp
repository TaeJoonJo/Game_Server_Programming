#pragma once

#include "NPC.h"

CNPC::CNPC()
	: m_bIsRun(false)
	, m_fX(0.f)
	, m_fY(0.f)
{

}

CNPC::~CNPC()
{
}

void CNPC::Initalize(DWORD dwid)
{
	m_bIsRun = true;

	m_dwID = dwid;

	m_fX = RandomINT(0.f, WORLD_WIDTH - 1.f);
	m_fY = RandomINT(0.f, WORLD_HEIGHT - 1.f);
}

void CNPC::Move()
{
	m_fX += RandomINT(-1.f, 1.f);
	m_fY += RandomINT(-1.f, 1.f);

	if (m_fX < 0.f)
		m_fX += 1.f;
	else if (m_fX > WORLD_WIDTH)
		m_fX -= 1.f;
	if (m_fY < 0.f)
		m_fY += 1.f;
	else if (m_fY > WORLD_HEIGHT)
		m_fY -= 1.f;
}
